import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
  await page.goto('http://localhost/ssgWebBZ/Login/ssgBZ010%2FFactura%2FVentas');
  await page.getByPlaceholder('Usuario').fill('administrador');
  await page.getByPlaceholder('Usuario').press('Tab');
  await page.getByPlaceholder('Contraseña').fill('rjs2528');
  await page.getByPlaceholder('Contraseña').press('Enter');
  await page.getByRole('button', { name: '+' }).click();
  await page.locator('form').filter({ hasText: 'Insertar facturación (ventas' }).getByLabel('Comprobante:').selectOption('FAVEA');
  await page.getByRole('textbox', { name: 'Cliente:' }).fill('carrar');
  await page.getByRole('textbox', { name: 'Cliente:' }).press('Enter');
  await page.getByRole('tab', { name: 'Cuerpo' }).click();
  await page.locator('nav').filter({ hasText: 'Artículos Afectar' }).getByRole('button').first().click();
  await page.getByPlaceholder('Ingrese un nombre de artículo').fill('00318');
  await page.getByPlaceholder('Ingrese un nombre de artículo').press('Enter');
  await page.getByRole('textbox', { name: 'Cantidad:' }).fill('11,00');
  await page.getByRole('textbox', { name: 'Cantidad:' }).press('Enter');
  //await page.locator('form').filter({ hasText: 'Insertar facturación (ventas' }).locator('#txtComprobanteNro').click();
  //await page.locator('form').filter({ hasText: 'Insertar facturación (ventas' }).locator('#txtComprobanteNro').press('Enter');
  const g = await (page.locator('css=body > div:nth-child(1) > div.principal > fieldset > div:nth-child(74) > form > nav > div > div.navbar-nav.ml-auto.animate__animated.animate__fadeInDown.animate__faster > div > div:nth-child(3) > button.btn.btn-success'))
  await g.click()
  //await page.getByRole('button', { name: '' }).click();
  //await page.getByRole('button', { name: '' }).first().click();
  //await page.locator('#chkOmitirCUITWeb').click();
  //await page.locator('#chkOmitirRG1394Web').click();
  //await page.locator('#chkOmitirApocrifos').click();
  //await page.locator('#chkOmitirCAI').click();
  //await page.getByRole('button', { name: 'Aceptar' }).click();
});


//para validar usar lo siguiente que debe ir de 0 a 1 en la list, es el list de abajo de todo
// getByRole('group').locator('div').filter({ hasText: 'Facturas (Ventas) Nú' }).locator('small')