import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
  await page.goto('about:blank');
  await page.goto('https://www.lanacion.com.ar/');
  await page.getByRole('link', { name: 'La Corte de los milagros mile' }).click();
});